(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))s(i);new MutationObserver(i=>{for(const o of i)if(o.type==="childList")for(const n of o.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&s(n)}).observe(document,{childList:!0,subtree:!0});function t(i){const o={};return i.integrity&&(o.integrity=i.integrity),i.referrerPolicy&&(o.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?o.credentials="include":i.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function s(i){if(i.ep)return;i.ep=!0;const o=t(i);fetch(i.href,o)}})();/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const x=globalThis,W=x.ShadowRoot&&(x.ShadyCSS===void 0||x.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,re=Symbol(),G=new WeakMap;let de=class{constructor(e,t,s){if(this._$cssResult$=!0,s!==re)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(W&&e===void 0){const s=t!==void 0&&t.length===1;s&&(e=G.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),s&&G.set(t,e))}return e}toString(){return this.cssText}};const ue=r=>new de(typeof r=="string"?r:r+"",void 0,re),pe=(r,e)=>{if(W)r.adoptedStyleSheets=e.map((t=>t instanceof CSSStyleSheet?t:t.styleSheet));else for(const t of e){const s=document.createElement("style"),i=x.litNonce;i!==void 0&&s.setAttribute("nonce",i),s.textContent=t.cssText,r.appendChild(s)}},Y=W?r=>r:r=>r instanceof CSSStyleSheet?(e=>{let t="";for(const s of e.cssRules)t+=s.cssText;return ue(t)})(r):r;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:ge,defineProperty:fe,getOwnPropertyDescriptor:me,getOwnPropertyNames:ve,getOwnPropertySymbols:$e,getPrototypeOf:ye}=Object,v=globalThis,K=v.trustedTypes,_e=K?K.emptyScript:"",N=v.reactiveElementPolyfillSupport,I=(r,e)=>r,j={toAttribute(r,e){switch(e){case Boolean:r=r?_e:null;break;case Object:case Array:r=r==null?r:JSON.stringify(r)}return r},fromAttribute(r,e){let t=r;switch(e){case Boolean:t=r!==null;break;case Number:t=r===null?null:Number(r);break;case Object:case Array:try{t=JSON.parse(r)}catch{t=null}}return t}},ne=(r,e)=>!ge(r,e),X={attribute:!0,type:String,converter:j,reflect:!1,useDefault:!1,hasChanged:ne};Symbol.metadata??(Symbol.metadata=Symbol("metadata")),v.litPropertyMetadata??(v.litPropertyMetadata=new WeakMap);let A=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??(this.l=[])).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=X){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){const s=Symbol(),i=this.getPropertyDescriptor(e,s,t);i!==void 0&&fe(this.prototype,e,i)}}static getPropertyDescriptor(e,t,s){const{get:i,set:o}=me(this.prototype,e)??{get(){return this[t]},set(n){this[t]=n}};return{get:i,set(n){const l=i==null?void 0:i.call(this);o==null||o.call(this,n),this.requestUpdate(e,l,s)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??X}static _$Ei(){if(this.hasOwnProperty(I("elementProperties")))return;const e=ye(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(I("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(I("properties"))){const t=this.properties,s=[...ve(t),...$e(t)];for(const i of s)this.createProperty(i,t[i])}const e=this[Symbol.metadata];if(e!==null){const t=litPropertyMetadata.get(e);if(t!==void 0)for(const[s,i]of t)this.elementProperties.set(s,i)}this._$Eh=new Map;for(const[t,s]of this.elementProperties){const i=this._$Eu(t,s);i!==void 0&&this._$Eh.set(i,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const s=new Set(e.flat(1/0).reverse());for(const i of s)t.unshift(Y(i))}else e!==void 0&&t.push(Y(e));return t}static _$Eu(e,t){const s=t.attribute;return s===!1?void 0:typeof s=="string"?s:typeof e=="string"?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){var e;this._$ES=new Promise((t=>this.enableUpdating=t)),this._$AL=new Map,this._$E_(),this.requestUpdate(),(e=this.constructor.l)==null||e.forEach((t=>t(this)))}addController(e){var t;(this._$EO??(this._$EO=new Set)).add(e),this.renderRoot!==void 0&&this.isConnected&&((t=e.hostConnected)==null||t.call(e))}removeController(e){var t;(t=this._$EO)==null||t.delete(e)}_$E_(){const e=new Map,t=this.constructor.elementProperties;for(const s of t.keys())this.hasOwnProperty(s)&&(e.set(s,this[s]),delete this[s]);e.size>0&&(this._$Ep=e)}createRenderRoot(){const e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return pe(e,this.constructor.elementStyles),e}connectedCallback(){var e;this.renderRoot??(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(e=this._$EO)==null||e.forEach((t=>{var s;return(s=t.hostConnected)==null?void 0:s.call(t)}))}enableUpdating(e){}disconnectedCallback(){var e;(e=this._$EO)==null||e.forEach((t=>{var s;return(s=t.hostDisconnected)==null?void 0:s.call(t)}))}attributeChangedCallback(e,t,s){this._$AK(e,s)}_$ET(e,t){var o;const s=this.constructor.elementProperties.get(e),i=this.constructor._$Eu(e,s);if(i!==void 0&&s.reflect===!0){const n=(((o=s.converter)==null?void 0:o.toAttribute)!==void 0?s.converter:j).toAttribute(t,s.type);this._$Em=e,n==null?this.removeAttribute(i):this.setAttribute(i,n),this._$Em=null}}_$AK(e,t){var o,n;const s=this.constructor,i=s._$Eh.get(e);if(i!==void 0&&this._$Em!==i){const l=s.getPropertyOptions(i),a=typeof l.converter=="function"?{fromAttribute:l.converter}:((o=l.converter)==null?void 0:o.fromAttribute)!==void 0?l.converter:j;this._$Em=i;const h=a.fromAttribute(t,l.type);this[i]=h??((n=this._$Ej)==null?void 0:n.get(i))??h,this._$Em=null}}requestUpdate(e,t,s){var i;if(e!==void 0){const o=this.constructor,n=this[e];if(s??(s=o.getPropertyOptions(e)),!((s.hasChanged??ne)(n,t)||s.useDefault&&s.reflect&&n===((i=this._$Ej)==null?void 0:i.get(e))&&!this.hasAttribute(o._$Eu(e,s))))return;this.C(e,t,s)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(e,t,{useDefault:s,reflect:i,wrapped:o},n){s&&!(this._$Ej??(this._$Ej=new Map)).has(e)&&(this._$Ej.set(e,n??t??this[e]),o!==!0||n!==void 0)||(this._$AL.has(e)||(this.hasUpdated||s||(t=void 0),this._$AL.set(e,t)),i===!0&&this._$Em!==e&&(this._$Eq??(this._$Eq=new Set)).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}const e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var s;if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??(this.renderRoot=this.createRenderRoot()),this._$Ep){for(const[o,n]of this._$Ep)this[o]=n;this._$Ep=void 0}const i=this.constructor.elementProperties;if(i.size>0)for(const[o,n]of i){const{wrapped:l}=n,a=this[o];l!==!0||this._$AL.has(o)||a===void 0||this.C(o,void 0,n,a)}}let e=!1;const t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),(s=this._$EO)==null||s.forEach((i=>{var o;return(o=i.hostUpdate)==null?void 0:o.call(i)})),this.update(t)):this._$EM()}catch(i){throw e=!1,this._$EM(),i}e&&this._$AE(t)}willUpdate(e){}_$AE(e){var t;(t=this._$EO)==null||t.forEach((s=>{var i;return(i=s.hostUpdated)==null?void 0:i.call(s)})),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&(this._$Eq=this._$Eq.forEach((t=>this._$ET(t,this[t])))),this._$EM()}updated(e){}firstUpdated(e){}};A.elementStyles=[],A.shadowRootOptions={mode:"open"},A[I("elementProperties")]=new Map,A[I("finalized")]=new Map,N==null||N({ReactiveElement:A}),(v.reactiveElementVersions??(v.reactiveElementVersions=[])).push("2.1.1");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const k=globalThis,L=k.trustedTypes,Z=L?L.createPolicy("lit-html",{createHTML:r=>r}):void 0,ae="$lit$",m=`lit$${Math.random().toFixed(9).slice(2)}$`,le="?"+m,be=`<${le}>`,b=document,T=()=>b.createComment(""),E=r=>r===null||typeof r!="object"&&typeof r!="function",V=Array.isArray,Se=r=>V(r)||typeof(r==null?void 0:r[Symbol.iterator])=="function",H=`[ 	
\f\r]`,C=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Q=/-->/g,ee=/>/g,$=RegExp(`>|${H}(?:([^\\s"'>=/]+)(${H}*=${H}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),te=/'/g,se=/"/g,ce=/^(?:script|style|textarea|title)$/i,Ae=r=>(e,...t)=>({_$litType$:r,strings:e,values:t}),d=Ae(1),S=Symbol.for("lit-noChange"),u=Symbol.for("lit-nothing"),ie=new WeakMap,y=b.createTreeWalker(b,129);function he(r,e){if(!V(r)||!r.hasOwnProperty("raw"))throw Error("invalid template strings array");return Z!==void 0?Z.createHTML(e):e}const we=(r,e)=>{const t=r.length-1,s=[];let i,o=e===2?"<svg>":e===3?"<math>":"",n=C;for(let l=0;l<t;l++){const a=r[l];let h,p,c=-1,g=0;for(;g<a.length&&(n.lastIndex=g,p=n.exec(a),p!==null);)g=n.lastIndex,n===C?p[1]==="!--"?n=Q:p[1]!==void 0?n=ee:p[2]!==void 0?(ce.test(p[2])&&(i=RegExp("</"+p[2],"g")),n=$):p[3]!==void 0&&(n=$):n===$?p[0]===">"?(n=i??C,c=-1):p[1]===void 0?c=-2:(c=n.lastIndex-p[2].length,h=p[1],n=p[3]===void 0?$:p[3]==='"'?se:te):n===se||n===te?n=$:n===Q||n===ee?n=C:(n=$,i=void 0);const f=n===$&&r[l+1].startsWith("/>")?" ":"";o+=n===C?a+be:c>=0?(s.push(h),a.slice(0,c)+ae+a.slice(c)+m+f):a+m+(c===-2?l:f)}return[he(r,o+(r[t]||"<?>")+(e===2?"</svg>":e===3?"</math>":"")),s]};class U{constructor({strings:e,_$litType$:t},s){let i;this.parts=[];let o=0,n=0;const l=e.length-1,a=this.parts,[h,p]=we(e,t);if(this.el=U.createElement(h,s),y.currentNode=this.el.content,t===2||t===3){const c=this.el.content.firstChild;c.replaceWith(...c.childNodes)}for(;(i=y.nextNode())!==null&&a.length<l;){if(i.nodeType===1){if(i.hasAttributes())for(const c of i.getAttributeNames())if(c.endsWith(ae)){const g=p[n++],f=i.getAttribute(c).split(m),O=/([.?@])?(.*)/.exec(g);a.push({type:1,index:o,name:O[2],strings:f,ctor:O[1]==="."?Ie:O[1]==="?"?ke:O[1]==="@"?Me:R}),i.removeAttribute(c)}else c.startsWith(m)&&(a.push({type:6,index:o}),i.removeAttribute(c));if(ce.test(i.tagName)){const c=i.textContent.split(m),g=c.length-1;if(g>0){i.textContent=L?L.emptyScript:"";for(let f=0;f<g;f++)i.append(c[f],T()),y.nextNode(),a.push({type:2,index:++o});i.append(c[g],T())}}}else if(i.nodeType===8)if(i.data===le)a.push({type:2,index:o});else{let c=-1;for(;(c=i.data.indexOf(m,c+1))!==-1;)a.push({type:7,index:o}),c+=m.length-1}o++}}static createElement(e,t){const s=b.createElement("template");return s.innerHTML=e,s}}function w(r,e,t=r,s){var n,l;if(e===S)return e;let i=s!==void 0?(n=t._$Co)==null?void 0:n[s]:t._$Cl;const o=E(e)?void 0:e._$litDirective$;return(i==null?void 0:i.constructor)!==o&&((l=i==null?void 0:i._$AO)==null||l.call(i,!1),o===void 0?i=void 0:(i=new o(r),i._$AT(r,t,s)),s!==void 0?(t._$Co??(t._$Co=[]))[s]=i:t._$Cl=i),i!==void 0&&(e=w(r,i._$AS(r,e.values),i,s)),e}class Ce{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){const{el:{content:t},parts:s}=this._$AD,i=((e==null?void 0:e.creationScope)??b).importNode(t,!0);y.currentNode=i;let o=y.nextNode(),n=0,l=0,a=s[0];for(;a!==void 0;){if(n===a.index){let h;a.type===2?h=new D(o,o.nextSibling,this,e):a.type===1?h=new a.ctor(o,a.name,a.strings,this,e):a.type===6&&(h=new Te(o,this,e)),this._$AV.push(h),a=s[++l]}n!==(a==null?void 0:a.index)&&(o=y.nextNode(),n++)}return y.currentNode=b,i}p(e){let t=0;for(const s of this._$AV)s!==void 0&&(s.strings!==void 0?(s._$AI(e,s,t),t+=s.strings.length-2):s._$AI(e[t])),t++}}class D{get _$AU(){var e;return((e=this._$AM)==null?void 0:e._$AU)??this._$Cv}constructor(e,t,s,i){this.type=2,this._$AH=u,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=s,this.options=i,this._$Cv=(i==null?void 0:i.isConnected)??!0}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return t!==void 0&&(e==null?void 0:e.nodeType)===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=w(this,e,t),E(e)?e===u||e==null||e===""?(this._$AH!==u&&this._$AR(),this._$AH=u):e!==this._$AH&&e!==S&&this._(e):e._$litType$!==void 0?this.$(e):e.nodeType!==void 0?this.T(e):Se(e)?this.k(e):this._(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==u&&E(this._$AH)?this._$AA.nextSibling.data=e:this.T(b.createTextNode(e)),this._$AH=e}$(e){var o;const{values:t,_$litType$:s}=e,i=typeof s=="number"?this._$AC(e):(s.el===void 0&&(s.el=U.createElement(he(s.h,s.h[0]),this.options)),s);if(((o=this._$AH)==null?void 0:o._$AD)===i)this._$AH.p(t);else{const n=new Ce(i,this),l=n.u(this.options);n.p(t),this.T(l),this._$AH=n}}_$AC(e){let t=ie.get(e.strings);return t===void 0&&ie.set(e.strings,t=new U(e)),t}k(e){V(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let s,i=0;for(const o of e)i===t.length?t.push(s=new D(this.O(T()),this.O(T()),this,this.options)):s=t[i],s._$AI(o),i++;i<t.length&&(this._$AR(s&&s._$AB.nextSibling,i),t.length=i)}_$AR(e=this._$AA.nextSibling,t){var s;for((s=this._$AP)==null?void 0:s.call(this,!1,!0,t);e!==this._$AB;){const i=e.nextSibling;e.remove(),e=i}}setConnected(e){var t;this._$AM===void 0&&(this._$Cv=e,(t=this._$AP)==null||t.call(this,e))}}class R{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,s,i,o){this.type=1,this._$AH=u,this._$AN=void 0,this.element=e,this.name=t,this._$AM=i,this.options=o,s.length>2||s[0]!==""||s[1]!==""?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=u}_$AI(e,t=this,s,i){const o=this.strings;let n=!1;if(o===void 0)e=w(this,e,t,0),n=!E(e)||e!==this._$AH&&e!==S,n&&(this._$AH=e);else{const l=e;let a,h;for(e=o[0],a=0;a<o.length-1;a++)h=w(this,l[s+a],t,a),h===S&&(h=this._$AH[a]),n||(n=!E(h)||h!==this._$AH[a]),h===u?e=u:e!==u&&(e+=(h??"")+o[a+1]),this._$AH[a]=h}n&&!i&&this.j(e)}j(e){e===u?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class Ie extends R{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===u?void 0:e}}class ke extends R{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==u)}}class Me extends R{constructor(e,t,s,i,o){super(e,t,s,i,o),this.type=5}_$AI(e,t=this){if((e=w(this,e,t,0)??u)===S)return;const s=this._$AH,i=e===u&&s!==u||e.capture!==s.capture||e.once!==s.once||e.passive!==s.passive,o=e!==u&&(s===u||i);i&&this.element.removeEventListener(this.name,this,s),o&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){var t;typeof this._$AH=="function"?this._$AH.call(((t=this.options)==null?void 0:t.host)??this.element,e):this._$AH.handleEvent(e)}}class Te{constructor(e,t,s){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=s}get _$AU(){return this._$AM._$AU}_$AI(e){w(this,e)}}const B=k.litHtmlPolyfillSupport;B==null||B(U,D),(k.litHtmlVersions??(k.litHtmlVersions=[])).push("3.3.1");const Ee=(r,e,t)=>{const s=(t==null?void 0:t.renderBefore)??e;let i=s._$litPart$;if(i===void 0){const o=(t==null?void 0:t.renderBefore)??null;s._$litPart$=i=new D(e.insertBefore(T(),o),o,void 0,t??{})}return i._$AI(r),i};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const _=globalThis;let M=class extends A{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var t;const e=super.createRenderRoot();return(t=this.renderOptions).renderBefore??(t.renderBefore=e.firstChild),e}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Ee(t,this.renderRoot,this.renderOptions)}connectedCallback(){var e;super.connectedCallback(),(e=this._$Do)==null||e.setConnected(!0)}disconnectedCallback(){var e;super.disconnectedCallback(),(e=this._$Do)==null||e.setConnected(!1)}render(){return S}};var oe;M._$litElement$=!0,M.finalized=!0,(oe=_.litElementHydrateSupport)==null||oe.call(_,{LitElement:M});const z=_.litElementPolyfillSupport;z==null||z({LitElement:M});(_.litElementVersions??(_.litElementVersions=[])).push("4.2.1");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ue={CHILD:2},De=r=>(...e)=>({_$litDirective$:r,values:e});class Oe{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,s){this._$Ct=e,this._$AM=t,this._$Ci=s}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class F extends Oe{constructor(e){if(super(e),this.it=u,e.type!==Ue.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(e){if(e===u||e==null)return this._t=void 0,this.it=e;if(e===S)return e;if(typeof e!="string")throw Error(this.constructor.directiveName+"() called with a non-string value");if(e===this.it)return this._t;this.it=e;const t=[e];return t.raw=t,this._t={_$litType$:this.constructor.resultType,strings:t,values:[]}}}F.directiveName="unsafeHTML",F.resultType=1;const Pe=De(F),J="chatMessages";function xe(){const r=localStorage.getItem(J);if(r)try{return JSON.parse(r)}catch{return[]}return[]}function q(r){try{localStorage.setItem(J,JSON.stringify(r))}catch(e){console.error("Failed to save messages:",e)}}function Le(){localStorage.removeItem(J)}function Re(r){if(!r)return"";let e=r.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");return e=e.replace(/\\([\\`*_{}[\]()#+\-.!|])/g,"&#92;$1"),e=e.replace(/```([a-z]*)\n?([\s\S]*?)```/g,(s,i,o)=>`<pre><code class="code-block">${o.trim()}</code></pre>`),e=e.replace(/`([^`]+)`/g,'<code class="inline-code">$1</code>'),e=e.replace(/\*\*\*(.+?)\*\*\*/g,"<strong><em>$1</em></strong>"),e=e.replace(/___(.+?)___/g,"<strong><em>$1</em></strong>"),e=e.replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>"),e=e.replace(/__(.+?)__/g,"<strong>$1</strong>"),e=e.replace(/\*([^\s*].*?)\*/g,"<em>$1</em>"),e=e.replace(/\b_([^\s_].*?)_\b/g,"<em>$1</em>"),e=e.replace(/~~(.+?)~~/g,"<del>$1</del>"),e=e.replace(/!\[([^\]]*)\]\(([^)]+)\)/g,'<img src="$2" alt="$1" class="markdown-image" />'),e=e.replace(/\[([^\]]+)\]\(([^)]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>'),e=e.replace(/^###### (.+)$/gm,"<h6>$1</h6>"),e=e.replace(/^##### (.+)$/gm,"<h5>$1</h5>"),e=e.replace(/^#### (.+)$/gm,"<h4>$1</h4>"),e=e.replace(/^### (.+)$/gm,"<h3>$1</h3>"),e=e.replace(/^## (.+)$/gm,"<h2>$1</h2>"),e=e.replace(/^# (.+)$/gm,"<h1>$1</h1>"),e=e.replace(/^\- \[x\] (.+)$/gm,'<li class="task-item"><input type="checkbox" checked disabled> $1</li>'),e=e.replace(/^\- \[ \] (.+)$/gm,'<li class="task-item"><input type="checkbox" disabled> $1</li>'),e=e.replace(/^[\-\*] (.+)$/gm,(s,i)=>s.includes('<li class="task-item">')?s:`<li>${i}</li>`),e=e.replace(/^\d+\. (.+)$/gm,'<li class="ordered-item">$1</li>'),e=e.replace(/^&gt;&gt; (.+)$/gm,'<blockquote class="nested-quote">$1</blockquote>'),e=e.replace(/^&gt; (.+)$/gm,"<blockquote>$1</blockquote>"),e=e.replace(/^(\-{3,}|\*{3,})$/gm,"<hr>"),e=Ne(e),e=He(e),e=e.split(/\n\n+/).map(s=>(s=s.trim(),s.match(/^<(h[1-6]|ul|ol|pre|blockquote|hr|table)/)?s:(s=s.replace(/\n/g,"<br>"),s?`<p>${s}</p>`:""))).join(""),e}function Ne(r){const e=/^\|(.+)\|\n\|[\s\-\|:]+\|\n((?:\|.+\|\n?)+)/gm;return r.replace(e,(t,s,i)=>{const n="<thead><tr>"+s.split("|").map(h=>h.trim()).filter(h=>h).map(h=>`<th>${h}</th>`).join("")+"</tr></thead>",a="<tbody>"+i.trim().split(`
`).map(h=>"<tr>"+h.split("|").map(c=>c.trim()).filter(c=>c).map(c=>`<td>${c}</td>`).join("")+"</tr>").join("")+"</tbody>";return`<table class="markdown-table">${n}${a}</table>`})}function He(r){return r=r.replace(/(<li>(?:(?!<li class=).)*?<\/li>\n?)+/g,e=>`<ul>${e}</ul>`),r=r.replace(/(<li class="task-item">.*?<\/li>\n?)+/g,e=>`<ul class="task-list">${e}</ul>`),r=r.replace(/(<li class="ordered-item">.*?<\/li>\n?)+/g,e=>(e=e.replace(/class="ordered-item"/g,""),`<ol>${e}</ol>`)),r}const Be=()=>window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?"http://localhost:3001":"https://vishapii.azurewebsites.net",P=Be();class ze extends M{static get properties(){return{messages:{type:Array},inputMessage:{type:String},isLoading:{type:Boolean},ragEnabled:{type:Boolean},showCrisisResources:{type:Boolean},crisisResources:{type:Array},talkModeActive:{type:Boolean},isListening:{type:Boolean},isSpeaking:{type:Boolean},talkModeSupported:{type:Boolean},speechError:{type:String},sidebarOpen:{type:Boolean},activeTab:{type:String},userInfo:{type:Object},userDocuments:{type:Array},isUploadingDoc:{type:Boolean},historySidebarOpen:{type:Boolean},chatSessions:{type:Array},currentChatId:{type:String},toastMessage:{type:String},showToast:{type:Boolean}}}constructor(){super(),this.messages=[],this.inputMessage="",this.isLoading=!1,this.ragEnabled=!0,this.showCrisisResources=!1,this.crisisResources=[],this.talkModeActive=!1,this.talkModeSupported=!1,this.isListening=!1,this.isSpeaking=!1,this.speechError="",this.recognition=null,this.currentUtterance=null,this.currentAudio=null,this.bargeInTimer=null,this.sessionId=this._generateSessionId(),this.currentChatId=this._getCurrentChatId(),this.chatSessions=this._loadChatSessions(),this.sidebarOpen=!1,this.historySidebarOpen=!1,this.activeTab="personal",this.userInfo=this._loadUserInfo(),this.userDocuments=this._loadUserDocuments(),this.isUploadingDoc=!1,this.toastMessage="",this.showToast=!1}_generateSessionId(){return`session_${Date.now()}_${Math.random().toString(36).substring(2,9)}`}createRenderRoot(){return this}connectedCallback(){super.connectedCallback(),this.messages=xe(),this.messages.length===0&&this._addWelcomeMessage(),this._initializeSpeech()}disconnectedCallback(){super.disconnectedCallback(),this._stopListening(),this._stopSpeaking()}_addWelcomeMessage(){this.messages=[{role:"assistant",content:"Hello there! I'm Vish, your friendly AI companion. I'm here to support you and provide a safe space for us to chat about whatever is on your mind. How are you feeling today? Remember, it's okay to not be okay, and I'm here to listen.",isWelcome:!0}],q(this.messages)}_clearChat(){this._startNewChat(),this._stopSpeaking(),fetch(P+"/clear-memory",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:this.sessionId})}).catch(e=>console.error("Failed to clear server memory:",e))}updated(e){e.has("messages")&&(q(this.messages),this._saveCurrentChat(),this._scrollToBottom())}_scrollToBottom(){const e=this.querySelector(".chat-messages");e&&(e.scrollTop=e.scrollHeight)}render(){return d`
      <div class="app-wrapper">
        <!-- Sidebar -->
        <div class="sidebar ${this.sidebarOpen?"open":""}">
          <div class="sidebar-header">
            <h3>
              ${this.activeTab==="personal"?"Personal Information":"My Documents"}
            </h3>
            <button
              class="sidebar-close-btn"
              @click=${this._toggleSidebar}
              aria-label="Close Sidebar"
            >
              ✕
            </button>
          </div>

          <!-- Sidebar Tabs -->
          <div class="sidebar-tabs">
            <button
              class="tab-btn ${this.activeTab==="personal"?"active":""}"
              @click=${()=>this._switchTab("personal")}
            >
              👤 Personal Info
            </button>
            <button
              class="tab-btn ${this.activeTab==="documents"?"active":""}"
              @click=${()=>this._switchTab("documents")}
            >
              📄 Documents
            </button>
          </div>

          <div class="sidebar-content">
            ${this.activeTab==="personal"?this._renderPersonalInfoTab():this._renderDocumentsTab()}
          </div>
        </div>

        <!-- Overlay for mobile -->
        ${this.sidebarOpen?d`
              <div class="sidebar-overlay" @click=${this._toggleSidebar}></div>
            `:""}

        <!-- Top Navigation Bar -->
        <div class="top-nav">
          <div class="nav-left">
            <button
              class="sidebar-toggle-btn"
              @click=${this._toggleSidebar}
              aria-label="Toggle Sidebar"
            >
              <span class="hamburger-icon">☰</span>
            </button>
            <h1 class="app-title">Vish AI 💚</h1>
          </div>
          <div class="nav-right">
            <button 
              class="rag-toggle ${this.ragEnabled?"active":""}"
              @click=${this._toggleRag}
            >
              📚 Resources
            </button>
            <button class="clear-chat-btn" @click=${this._clearChat}>
              ➕ New Chat
            </button>
            <button class="history-btn" @click=${this._toggleHistorySidebar}>
              📜 History
            </button>
          </div>
        </div>

        <div class="chat-container">
          <!-- Crisis Resources Modal -->
          ${this.showCrisisResources?d`
                <div class="modal-overlay" @click=${this._closeCrisisModal}>
                  <div
                    class="crisis-modal"
                    @click=${e=>e.stopPropagation()}
                  >
                    <div class="modal-header">
                      <h3>🆘 Help is Always Available</h3>
                      <button
                        class="close-modal-btn"
                        @click=${this._closeCrisisModal}
                        aria-label="Close"
                      >
                        ✕
                      </button>
                    </div>
                    <div class="modal-content">
                      <p class="crisis-intro">
                        You're not alone. Here are immediate resources that can
                        help:
                      </p>
                      <ul class="crisis-list">
                        ${this.crisisResources.map(e=>d`
                            <li>
                              <strong>${e.name}</strong>
                              ${e.contact?d`<div class="resource-contact">
                                    ${e.contact}
                                  </div>`:""}
                              ${e.url?d`<div>
                                    <a
                                      href="${e.url}"
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      >${e.url}</a
                                    >
                                  </div>`:""}
                            </li>
                          `)}
                      </ul>
                      <p class="crisis-note">
                        <strong>⚠️ Emergency:</strong> If you're feeling unsafe
                        right now, please call emergency services (911 in the
                        US) or reach out to someone you trust immediately.
                      </p>
                    </div>
                    <div class="modal-footer">
                      <button
                        class="close-btn"
                        @click=${this._closeCrisisModal}
                      >
                        Close
                      </button>
                    </div>
                  </div>
                </div>
              `:""}

          <div class="chat-messages">
            ${this.messages.map(e=>d`
                <div
                  class="message ${e.role==="user"?"user-message":"ai-message"} ${e.isWelcome?"welcome-message":""}"
                >
                  <div class="message-content">
                    <span class="message-sender"
                      >${e.role==="user"?"👤 You":"💚 Vish"}</span
                    >
                    <div class="message-text">
                      ${Pe(Re(e.content))}
                    </div>
                    ${this.ragEnabled&&e.sources&&e.sources.length>0?d`
                          <details class="sources">
                            <summary>📚 Resources I'm Drawing From</summary>
                            <div class="sources-content">
                              ${e.sources.map(t=>d`<p>${t}</p>`)}
                            </div>
                          </details>
                        `:""}
                  </div>
                </div>
              `)}
            ${this.isLoading?d`
                  <div class="message ai-message thinking">
                    <div class="message-content">
                      <span class="message-sender">Vish</span>
                      <p>
                        <span class="typing-indicator"
                          >Thinking<span>.</span><span>.</span
                          ><span>.</span></span
                        >
                      </p>
                    </div>
                  </div>
                `:""}
          </div>

          <div class="chat-input-container">
            <input
              type="text"
              class="chat-input"
              placeholder="Share your thoughts..."
              .value=${this.inputMessage}
              @input=${this._handleInput}
              @keyup=${this._handleKeyUp}
            />
            <button
              class="talk-mode-btn ${this.talkModeActive?"active":""} ${this.isSpeaking?"speaking":""}"
              @click=${this._toggleTalkMode}
              ?disabled=${!this.talkModeSupported}
              aria-pressed=${this.talkModeActive}
              title="${this.talkModeActive?this.isSpeaking?"Speaking":"Listening":"Talk Mode"}"
            >
              ${this.isSpeaking?d`
                    <div class="audio-bars-small">
                      <div class="bar"></div>
                      <div class="bar"></div>
                      <div class="bar"></div>
                      <div class="bar"></div>
                      <div class="bar"></div>
                    </div>
                  `:d`
                    <span class="mic-icon"
                      >${this.talkModeActive?"🎤":"🎙️"}</span
                    >
                  `}
            </button>
            <button
              class="send-button"
              @click=${e=>{e.preventDefault(),this._sendMessage()}}
              ?disabled=${this.isLoading||!this.inputMessage.trim()}
            >
              Send
            </button>
          </div>
        </div>

        <div class="app-footer">
          <p class="disclaimer">
            This is an AI LLM not a professional therapist. Kindly consult a
            professional for serious issues.
          </p>
          ${this.talkModeSupported?"":d`<p class="speech-warning">
                Speech features unavailable in this browser.
              </p>`}
          ${this.speechError?d`<p class="speech-warning">${this.speechError}</p>`:""}
        </div>

        <!-- History Sidebar -->
        <div class="history-sidebar ${this.historySidebarOpen?"open":""}">
          <div class="history-header">
            <h3>💬 Chat History</h3>
            <button
              class="sidebar-close-btn"
              @click=${this._toggleHistorySidebar}
              aria-label="Close History"
            >
              ✕
            </button>
          </div>

          <div class="history-content">
            ${this.chatSessions.length===0?d`
                  <p class="no-history">
                    No chat history yet. Start a conversation!
                  </p>
                `:d`
                  <div class="history-actions">
                    <button
                      class="delete-all-btn"
                      @click=${this._deleteAllChats}
                    >
                      🗑️ Delete All
                    </button>
                  </div>
                  <ul class="history-list">
                    ${this.chatSessions.map(e=>d`
                        <li
                          class="history-item ${e.id===this.currentChatId?"active":""}"
                          @click=${()=>this._loadChatSession(e.id)}
                        >
                          <div class="history-item-content">
                            <span class="history-title">${e.title}</span>
                            <span class="history-timestamp"
                              >📅
                              ${this._formatDateTime(e.createdAt)}</span
                            >
                            <span class="history-messages"
                              >${e.messages.length} messages</span
                            >
                          </div>
                          <div class="history-actions-btns">
                            <button
                              class="history-edit-btn"
                              @click=${t=>this._renameChat(e.id,t)}
                              title="Rename chat"
                            >
                              ✏️
                            </button>
                            <button
                              class="history-delete-btn"
                              @click=${t=>this._deleteChat(e.id,t)}
                              title="Delete chat"
                            >
                              🗑️
                            </button>
                          </div>
                        </li>
                      `)}
                  </ul>
                `}
          </div>
        </div>

        <!-- History Overlay for mobile -->
        ${this.historySidebarOpen?d`
              <div
                class="history-overlay"
                @click=${this._toggleHistorySidebar}
              ></div>
            `:""}

        <!-- Toast Notification -->
        ${this.showToast?d`
              <div class="toast-notification">
                ${this.toastMessage}
              </div>
            `:""}
      </div>
    `}_toggleRag(e){this.ragEnabled=!this.ragEnabled,this._showToast(this.ragEnabled?"📚 Resources Enabled":"📚 Resources Disabled")}_showToast(e){this.toastMessage=e,this.showToast=!0,setTimeout(()=>{this.showToast=!1},1900)}_handleInput(e){this.inputMessage=e.target.value}_handleKeyUp(e){e.key==="Enter"&&this.inputMessage.trim()&&!this.isLoading&&this._sendMessage()}_toggleSidebar(){this.sidebarOpen=!this.sidebarOpen}_switchTab(e){this.activeTab=e}_toggleHistorySidebar(){this.historySidebarOpen=!this.historySidebarOpen}_closeCrisisModal(){this.showCrisisResources=!1}async _sendMessage(e=null,t={}){var i;const s=(e??this.inputMessage).trim();if(!(!s||this.isLoading)){this.messages=[...this.messages,{role:"user",content:s,viaSpeech:!!t.fromSpeech}],e===null&&(this.inputMessage=""),this.isLoading=!0;try{const o=await this._apiCall(s);console.log("📨 API Response:",{hasReply:!!o.reply,replyLength:(i=o.reply)==null?void 0:i.length,hasAudio:!!o.audioData,talkMode:this.talkModeActive}),this.messages=[...this.messages,{role:"assistant",content:o.reply,sources:Array.isArray(o.sources)?o.sources:[],talkMode:this.talkModeActive}];const n=o.reply.includes("988")&&o.reply.includes("741741");(o.isCrisis&&o.resources||n)&&(this.crisisResources=o.resources||[{name:"National Suicide Prevention Lifeline",contact:"988"},{name:"Crisis Text Line",contact:"Text HOME to 741741"},{name:"International Association for Suicide Prevention",url:"https://www.iasp.info/resources/Crisis_Centres/"}],this.showCrisisResources=!0),this.talkModeActive&&o.audioData?this._playAudioData(o.audioData):this.talkModeActive&&o.reply&&this._speakResponse(o.reply)}catch(o){console.error("Error calling model:",o);let n="I'm sorry, I'm having trouble responding right now. ";o.message.includes("Failed to fetch")||o.message.includes("NetworkError")?n+="I couldn't connect to the server. Please check your internet connection. ":o.message.includes("API returned")&&(n+="The server encountered an error processing your request. "),n+="If you're feeling in crisis, please call a crisis service like 988 (in the US) or your local emergency number.",this.messages=[...this.messages,{role:"assistant",content:n}]}finally{this.isLoading=!1}}}async _apiCall(e){const t=this.talkModeActive?"/chat-audio":"/chat",s=P+t;console.log(`🌐 Calling API: ${s}`);const i=await fetch(s,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:e,useRAG:this.ragEnabled,sessionId:this.sessionId,mode:this.talkModeActive?"talk":"chat",userInfo:this._hasUserInfo()?this.userInfo:null})});if(!i.ok){const o=await i.text();throw console.error(`❌ API Error: ${i.status} - ${o}`),new Error(`API returned ${i.status}: ${o}`)}return await i.json()}_toggleTalkMode(){this.talkModeSupported&&(this.talkModeActive=!this.talkModeActive,this.speechError="",this.talkModeActive?this._startListening():(this._stopListening(),this._stopSpeaking()))}_initializeSpeech(){const e=typeof window<"u"&&"speechSynthesis"in window,t=typeof window<"u"&&(window.SpeechRecognition||window.webkitSpeechRecognition);if(!e||!t){this.talkModeSupported=!1;return}this.talkModeSupported=!0,this.recognition=new t,this.recognition.lang="en-US",this.recognition.continuous=!1,this.recognition.interimResults=!1,this.recognition.maxAlternatives=1,this.recognition.onstart=()=>{this.isListening=!0,this.requestUpdate()},this.recognition.onspeechstart=()=>{this.isSpeaking&&this._stopSpeaking()},this.recognition.onend=()=>{this.isListening=!1,this.requestUpdate(),this.talkModeActive&&!this.isSpeaking&&setTimeout(()=>this._startListening(),300)},this.recognition.onerror=s=>{s.error!=="no-speech"&&(this.speechError="Speech recognition error: "+s.error,this.talkModeActive=!1,this._stopListening(),this._stopSpeaking(),this.requestUpdate())},this.recognition.onresult=s=>{var o,n,l,a;const i=(a=(l=(n=(o=s.results)==null?void 0:o[0])==null?void 0:n[0])==null?void 0:l.transcript)==null?void 0:a.trim();i&&this._sendMessage(i,{fromSpeech:!0})}}_startListening(){if(!(!this.recognition||this.isListening))try{this.recognition.start()}catch{}}_stopListening(){if(this.recognition){try{this.recognition.stop()}catch{}this.isListening=!1,this.requestUpdate()}}_stopSpeaking(){typeof window>"u"||!window.speechSynthesis||(this.bargeInTimer&&(clearTimeout(this.bargeInTimer),this.bargeInTimer=null),this.currentAudio&&(this.currentAudio.pause(),this.currentAudio=null),window.speechSynthesis.cancel(),this.isSpeaking=!1,this.currentUtterance=null)}_playAudioData(e){if(e){this._stopSpeaking();try{const t=atob(e),s=new Array(t.length);for(let a=0;a<t.length;a++)s[a]=t.charCodeAt(a);const i=new Blob([new Uint8Array(s)],{type:"audio/mp3"}),o=URL.createObjectURL(i),n=new Audio(o);this.currentAudio=n,n.onplay=()=>{this.isSpeaking=!0,this._stopListening(),this.requestUpdate()};const l=()=>{this.isSpeaking=!1,URL.revokeObjectURL(o),this.currentAudio=null,this.requestUpdate(),this.talkModeActive&&this._startListening()};n.onended=l,n.onerror=a=>{console.error("Audio playback error:",a),l()},n.play().catch(a=>{console.error("Failed to play audio:",a),l()})}catch(t){console.error("Error processing audio data:",t),this.isSpeaking=!1,this.requestUpdate()}}}_speakResponse(e){if(typeof window>"u"||!window.speechSynthesis)return;this._stopSpeaking();const t=new SpeechSynthesisUtterance(e);this.currentUtterance=t,t.onstart=()=>{this.isSpeaking=!0,this._stopListening(),this.requestUpdate(),this._scheduleBargeInResume()};const s=()=>{this.isSpeaking=!1,this.requestUpdate(),this.talkModeActive&&this._startListening()};t.onend=s,t.onerror=s,window.speechSynthesis.speak(t)}_scheduleBargeInResume(){this.talkModeActive&&(this.bargeInTimer&&clearTimeout(this.bargeInTimer),this.bargeInTimer=setTimeout(()=>{this.bargeInTimer=null,this.talkModeActive&&this.isSpeaking&&this._startListening()},600))}_renderPersonalInfoTab(){return d`
      <p class="sidebar-description">
        Help Vish understand you better! This information is optional and will
        be used to personalize your experience.
      </p>

      <form class="user-info-form" @submit=${this._saveUserInfo}>
        <div class="form-group">
          <label for="userName">Name</label>
          <input
            type="text"
            id="userName"
            placeholder="Your name"
            .value=${this.userInfo.name||""}
            @input=${e=>this._updateUserInfo("name",e.target.value)}
          />
        </div>

        <div class="form-group">
          <label for="userAge">Age</label>
          <input
            type="number"
            id="userAge"
            placeholder="Your age"
            min="1"
            max="120"
            .value=${this.userInfo.age||""}
            @input=${e=>this._updateUserInfo("age",e.target.value)}
          />
        </div>

        <div class="form-group">
          <label for="gender">Gender</label>
          <select
            id="gender"
            .value=${this.userInfo.gender||""}
            @change=${e=>this._updateUserInfo("gender",e.target.value)}
          >
            <option value="">Prefer not to say</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="non-binary">Non-binary</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div class="form-group">
          <label for="pronouns">Preferred Pronouns (Optional)</label>
          <input
            type="text"
            id="pronouns"
            placeholder="e.g., he/him, she/her, they/them"
            .value=${this.userInfo.pronouns||""}
            @input=${e=>this._updateUserInfo("pronouns",e.target.value)}
          />
        </div>

        <div class="form-group">
          <label>Occupation</label>
          <div class="radio-group">
            <label class="radio-label">
              <input
                type="radio"
                name="occupationType"
                value="student"
                ?checked=${this.userInfo.occupationType==="student"}
                @change=${e=>this._updateUserInfo("occupationType",e.target.value)}
              />
              <span>Student</span>
            </label>
            <label class="radio-label">
              <input
                type="radio"
                name="occupationType"
                value="working"
                ?checked=${this.userInfo.occupationType==="working"}
                @change=${e=>this._updateUserInfo("occupationType",e.target.value)}
              />
              <span>Working</span>
            </label>
          </div>
        </div>

        ${this.userInfo.occupationType==="student"?d`
              <div class="form-group">
                <label for="course">Course</label>
                <input
                  type="text"
                  id="course"
                  placeholder="e.g., BTech, BBA, MBA"
                  .value=${this.userInfo.course||""}
                  @input=${e=>this._updateUserInfo("course",e.target.value)}
                />
              </div>

              <div class="form-group">
                <label for="branch">Branch/Specialization</label>
                <input
                  type="text"
                  id="branch"
                  placeholder="e.g., CSE, ECE, Finance"
                  .value=${this.userInfo.branch||""}
                  @input=${e=>this._updateUserInfo("branch",e.target.value)}
                />
              </div>
            `:""}
        ${this.userInfo.occupationType==="working"?d`
              <div class="form-group">
                <label for="jobTitle">Job Title</label>
                <input
                  type="text"
                  id="jobTitle"
                  placeholder="Your job title"
                  .value=${this.userInfo.jobTitle||""}
                  @input=${e=>this._updateUserInfo("jobTitle",e.target.value)}
                />
              </div>

              <div class="form-group">
                <label for="organization">Organization</label>
                <input
                  type="text"
                  id="organization"
                  placeholder="Your company/organization"
                  .value=${this.userInfo.organization||""}
                  @input=${e=>this._updateUserInfo("organization",e.target.value)}
                />
              </div>
            `:""}

        <div class="form-group">
          <label for="currentMood">Current Mood/Emotional State</label>
          <select
            id="currentMood"
            .value=${this.userInfo.currentMood||""}
            @change=${e=>this._updateUserInfo("currentMood",e.target.value)}
          >
            <option value="">Select if you'd like...</option>
            <option value="great">Great - Feeling positive</option>
            <option value="good">Good - Doing well</option>
            <option value="okay">Okay - Getting by</option>
            <option value="struggling">
              Struggling - Finding things difficult
            </option>
            <option value="difficult">
              Very Difficult - Need extra support
            </option>
          </select>
        </div>

        <div class="form-group">
          <label for="concerns">Primary Concerns or Goals (Optional)</label>
          <textarea
            id="concerns"
            placeholder="What brings you here? What would you like help with? (e.g., anxiety, stress management, work-life balance, relationships)"
            rows="3"
            .value=${this.userInfo.concerns||""}
            @input=${e=>this._updateUserInfo("concerns",e.target.value)}
          ></textarea>
        </div>

        <div class="form-group">
          <label for="communicationStyle">Preferred Communication Style</label>
          <select
            id="communicationStyle"
            .value=${this.userInfo.communicationStyle||""}
            @change=${e=>this._updateUserInfo("communicationStyle",e.target.value)}
          >
            <option value="">No preference</option>
            <option value="direct">Direct - Get straight to the point</option>
            <option value="gentle">Gentle - Soft and encouraging</option>
            <option value="analytical">
              Analytical - Logical and structured
            </option>
            <option value="empathetic">
              Empathetic - Understanding and emotional
            </option>
          </select>
        </div>

        <div class="form-group">
          <label for="previousTherapy"
            >Previous Therapy/Counseling Experience</label
          >
          <select
            id="previousTherapy"
            .value=${this.userInfo.previousTherapy||""}
            @change=${e=>this._updateUserInfo("previousTherapy",e.target.value)}
          >
            <option value="">Prefer not to say</option>
            <option value="yes-current">Yes - Currently in therapy</option>
            <option value="yes-past">Yes - Previously had therapy</option>
            <option value="no">No - First time seeking support</option>
          </select>
        </div>

        <div class="form-group">
          <label for="preferredRole"
            >How would you like Vish to interact with you?</label
          >
          <select
            id="preferredRole"
            .value=${this.userInfo.preferredRole||""}
            @change=${e=>this._updateUserInfo("preferredRole",e.target.value)}
          >
            <option value="">No preference</option>
            <option value="friend">Friend - Casual and supportive</option>
            <option value="therapist">
              Therapist - Professional and structured
            </option>
            <option value="mentor">Mentor - Guiding and advisory</option>
            <option value="sibling">Sibling - Familiar and caring</option>
            <option value="family">Family Member - Warm and protective</option>
            <option value="partner">
              Partner/Significant Other - Intimate and understanding
            </option>
            <option value="coach">
              Life Coach - Motivational and goal-oriented
            </option>
            <option value="confidant">
              Confidant - Trustworthy and non-judgmental
            </option>
          </select>
        </div>

        <div class="form-group">
          <label for="aboutMe">About Me</label>
          <textarea
            id="aboutMe"
            placeholder="Share anything you'd like Vish to know about you..."
            rows="4"
            .value=${this.userInfo.aboutMe||""}
            @input=${e=>this._updateUserInfo("aboutMe",e.target.value)}
          ></textarea>
        </div>

        <button type="submit" class="save-info-btn">Save Information</button>
        ${this._hasUserInfo()?d`
              <button
                type="button"
                class="clear-info-btn"
                @click=${this._clearUserInfo}
              >
                Clear Information
              </button>
            `:""}
      </form>
    `}_renderDocumentsTab(){return d`
      <p class="sidebar-description">
        Upload your own documents for Vish to reference. This helps provide more
        personalized and contextual support.
      </p>

      <div class="document-upload-section">
        <input
          type="file"
          id="file-upload-input"
          accept=".pdf,.txt,.doc,.docx"
          @change=${this._handleFileUpload}
          style="display: none;"
          ?disabled=${this.isUploadingDoc}
        />
        <label for="file-upload-input" class="upload-label">
          <span class="upload-btn" ?disabled=${this.isUploadingDoc}>
            ${this.isUploadingDoc?"⏳ Uploading...":"📤 Upload Document"}
          </span>
        </label>
        <p class="upload-hint">Supported: PDF, TXT, DOC, DOCX (Max 10MB)</p>
      </div>

      <div class="documents-list">
        <h4>Your Documents (${this.userDocuments.length})</h4>
        ${this.userDocuments.length===0?d`
              <p class="no-documents">
                No documents uploaded yet. Add your first document to get
                started!
              </p>
            `:d`
              <ul class="doc-items">
                ${this.userDocuments.map((e,t)=>d`
                    <li class="doc-item">
                      <div class="doc-info">
                        <span class="doc-icon">📄</span>
                        <div class="doc-details">
                          <span class="doc-name">${e.name}</span>
                          <span class="doc-size"
                            >${this._formatFileSize(e.size)} •
                            ${this._formatDate(e.uploadedAt)}</span
                          >
                        </div>
                      </div>
                      <button
                        class="doc-delete-btn"
                        @click=${()=>this._deleteDocument(t)}
                        title="Remove document"
                      >
                        🗑️
                      </button>
                    </li>
                  `)}
              </ul>
            `}
      </div>
    `}_loadUserInfo(){try{const e=localStorage.getItem("vishUserInfo");return e?JSON.parse(e):{}}catch(e){return console.error("Error loading user info:",e),{}}}_updateUserInfo(e,t){this.userInfo={...this.userInfo,[e]:t}}_saveUserInfo(e){e.preventDefault();try{localStorage.setItem("vishUserInfo",JSON.stringify(this.userInfo));const t=e.target.querySelector(".save-info-btn"),s=t.textContent;t.textContent="✓ Saved!",t.style.backgroundColor="#6abf9f",setTimeout(()=>{t.textContent=s,t.style.backgroundColor=""},2e3),this.requestUpdate()}catch(t){console.error("Error saving user info:",t),alert("Failed to save information. Please try again.")}}_clearUserInfo(e){e.preventDefault(),confirm("Are you sure you want to clear all your personal information?")&&(this.userInfo={},localStorage.removeItem("vishUserInfo"),this.requestUpdate())}_hasUserInfo(){return Object.keys(this.userInfo).some(e=>this.userInfo[e]&&this.userInfo[e].toString().trim())}_loadUserDocuments(){try{const e=localStorage.getItem("vishUserDocuments");return e?JSON.parse(e):[]}catch(e){return console.error("Error loading user documents:",e),[]}}_saveUserDocuments(){try{localStorage.setItem("vishUserDocuments",JSON.stringify(this.userDocuments))}catch(e){console.error("Error saving user documents:",e)}}async _handleFileUpload(e){const t=e.target.files[0];if(!t)return;if(t.size>10*1024*1024){alert("File size must be less than 10MB"),e.target.value="";return}const s=[".pdf",".txt",".doc",".docx"],i="."+t.name.split(".").pop().toLowerCase();if(!s.includes(i)){alert("Please upload a PDF, TXT, DOC, or DOCX file"),e.target.value="";return}this.isUploadingDoc=!0;try{const o=new FormData;o.append("document",t);const n=await fetch(P+"/upload-document",{method:"POST",body:o});if(!n.ok)throw new Error("Upload failed");const l=await n.json();this.userDocuments=[...this.userDocuments,{id:l.id||Date.now().toString(),name:t.name,size:t.size,uploadedAt:new Date().toISOString(),path:l.path||t.name}],this._saveUserDocuments(),alert(`✓ ${t.name} uploaded successfully!`)}catch(o){console.error("Error uploading document:",o),alert("Failed to upload document. Please try again.")}finally{this.isUploadingDoc=!1,e.target.value=""}}async _deleteDocument(e){if(!confirm(`Are you sure you want to remove "${this.userDocuments[e].name}"?`))return;const t=this.userDocuments[e];try{await fetch(P+`/delete-document/${t.id}`,{method:"DELETE"}),this.userDocuments=this.userDocuments.filter((s,i)=>i!==e),this._saveUserDocuments()}catch(s){console.error("Error deleting document:",s),alert("Failed to delete document. It has been removed from your list."),this.userDocuments=this.userDocuments.filter((i,o)=>o!==e),this._saveUserDocuments()}}_formatFileSize(e){return e<1024?e+" B":e<1024*1024?(e/1024).toFixed(1)+" KB":(e/(1024*1024)).toFixed(1)+" MB"}_formatDate(e){const t=new Date(e),i=new Date-t,o=Math.floor(i/6e4),n=Math.floor(i/36e5),l=Math.floor(i/864e5);return o<1?"Just now":o<60?`${o}m ago`:n<24?`${n}h ago`:l<7?`${l}d ago`:t.toLocaleDateString()}_loadChatSessions(){try{const e=localStorage.getItem("vishChatSessions");return e?JSON.parse(e):[]}catch(e){return console.error("Error loading chat sessions:",e),[]}}_saveChatSessions(){try{localStorage.setItem("vishChatSessions",JSON.stringify(this.chatSessions))}catch(e){console.error("Error saving chat sessions:",e)}}_getCurrentChatId(){const e=localStorage.getItem("vishCurrentChatId");if(e)return e;const t="chat_"+Date.now()+"_"+Math.random().toString(36).substring(2,9);return localStorage.setItem("vishCurrentChatId",t),t}_saveCurrentChat(){if(this.messages.length===0)return;const e=this.chatSessions.findIndex(n=>n.id===this.currentChatId),t=e>=0?this.chatSessions[e].title:null,i=!t||t==="New Chat"?this._generateChatTitle():t,o={id:this.currentChatId,title:i,messages:this.messages,sessionId:this.sessionId,createdAt:e>=0?this.chatSessions[e].createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};e>=0?this.chatSessions[e]=o:this.chatSessions=[o,...this.chatSessions],this._saveChatSessions()}_generateChatTitle(){const e=this.messages.find(t=>t.role==="user");if(e){const t=e.content.substring(0,30);return t.length<e.content.length?t+"...":t}return"New Chat"}_startNewChat(e=!1){e||this._saveCurrentChat(),this.messages=[],Le(),this.currentChatId="chat_"+Date.now()+"_"+Math.random().toString(36).substring(2,9),this.sessionId=this._generateSessionId(),localStorage.setItem("vishCurrentChatId",this.currentChatId),this._addWelcomeMessage(),this.requestUpdate()}_toggleHistorySidebar(){this.historySidebarOpen=!this.historySidebarOpen}_loadChatSession(e){const t=this.chatSessions.find(s=>s.id===e);t&&(this.messages.length>0&&this._saveCurrentChat(),this.currentChatId=t.id,this.sessionId=t.sessionId,this.messages=t.messages,localStorage.setItem("vishCurrentChatId",e),q(this.messages),this.historySidebarOpen=!1,this.requestUpdate())}_deleteChat(e,t){t.stopPropagation();const s=this.chatSessions.find(o=>o.id===e);if(!s||!confirm(`Delete chat: "${s.title}"?`))return;const i=e===this.currentChatId;this.chatSessions=this.chatSessions.filter(o=>o.id!==e),this._saveChatSessions(),i&&this._startNewChat(!0),this.requestUpdate()}_deleteAllChats(){confirm("Delete all chat history? This cannot be undone.")&&(this.chatSessions=[],this._saveChatSessions(),this._startNewChat(!0),this.requestUpdate())}_renameChat(e,t){t.stopPropagation();const s=this.chatSessions.find(o=>o.id===e);if(!s)return;const i=prompt("Enter new chat name:",s.title);!i||i.trim()===""||(s.title=i.trim(),this._saveChatSessions(),e===this.currentChatId&&this._saveCurrentChat(),this.requestUpdate())}_formatDateTime(e){const t=new Date(e),i=new Date-t,o=Math.floor(i/864e5);return o===0?t.toLocaleTimeString("en-US",{hour:"numeric",minute:"2-digit",hour12:!0}):o<7?t.toLocaleDateString("en-US",{weekday:"short",hour:"numeric",minute:"2-digit",hour12:!0}):t.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0})}}customElements.define("chat-interface",ze);
